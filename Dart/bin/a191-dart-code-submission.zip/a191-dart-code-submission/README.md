# Submission Dart

Selamat datang di tahap akhir kelas Dart!

Untuk menyelesaikan kelas ini, Anda perlu mengerjakan **Submission** sebagai bentuk evaluasi pemahaman Anda. Submission ini terdiri dari **4 Exam** yang harus Anda selesaikan.

- [Exam 1](bin/exam1/README%20-%20Exam%201.md)
- [Exam 2](bin/exam2/README%20-%20Exam%202.md)
- [Exam 3](bin/exam3/README%20-%20Exam%203.md)
- [Exam 4](bin/exam4/README%20-%20Exam%204.md)

Setiap Exam memiliki **3 tugas (TODO)** yang bisa dikerjakan. Anda bebas memilih tugas mana yang ingin diselesaikan terlebih dahulu. Namun, **setiap Exam harus memiliki minimal 1 tugas yang terselesaikan** agar dianggap memenuhi kriteria kelulusan.

Gunakan pengetahuan yang telah Anda peroleh selama belajar di kelas ini dan tunjukkan kemampuan Anda dalam menguasai Dart.

Selamat mengerjakan dan semoga sukses!
